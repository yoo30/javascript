/* 
Activité 1
*/

// Liste des liens Web à afficher. Un lien est défini par :
// - son titre
// - son URL
// - son auteur (la personne qui l'a publié)
var listeLiens = [
    {
        titre: "So Foot",
        url: "http://sofoot.com",
        auteur: "yann.usaille"
    },
    {
        titre: "Guide d'autodéfense numérique",
        url: "http://guide.boum.org",
        auteur: "paulochon"
    },
    {
        titre: "L'encyclopédie en ligne Wikipedia",
        url: "http://Wikipedia.org",
        auteur: "annie.zette"
    }
];

var ulElt = document.createElement("ul"); 

for(var i = 0; i < listeLiens.length; i++){

    var liElt = document.createElement("li");
    liElt.style.listStyleType = "none";
    liElt.className = "lien";


    var divElt = document.createElement("div");
    divElt.className = "bloc";
    liElt.appendChild(divElt);
    

    var titreElt = document.createElement("h3");
    titreElt.textContent = listeLiens[i].titre;
    titreElt.style.display = "inline";

    var lienElt = document.createElement("a");
    lienElt.href = listeLiens[i].url;
    lienElt.appendChild(titreElt);
    lienElt.style.textDecoration = "none";
    lienElt.style.color = "#428bca";
    liElt.appendChild(lienElt);
    divElt.appendChild(lienElt);


    var urlElt = document.createElement("p");
    urlElt.textContent = listeLiens[i].url;
    urlElt.style.display = "inline";
    urlElt.style.margin = "10px";
    liElt.appendChild(urlElt);
    divElt.appendChild(urlElt);


    var auteurElt = document.createElement("p");
    auteurElt.textContent = listeLiens[i].auteur;
    liElt.appendChild(auteurElt);

    ulElt.appendChild(liElt);

  
}

document.getElementById("contenu").appendChild(ulElt);




